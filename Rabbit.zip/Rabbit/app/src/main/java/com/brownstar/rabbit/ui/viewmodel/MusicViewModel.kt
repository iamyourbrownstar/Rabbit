package com.brownstar.rabbit.ui.viewmodel

import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.MediaStore
import android.media.MediaMetadataRetriever
import java.util.Locale
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.brownstar.rabbit.data.model.Song
import com.brownstar.rabbit.data.repository.MusicRepository
import com.brownstar.rabbit.data.model.Album
import com.brownstar.rabbit.data.SettingsManager
import com.brownstar.rabbit.data.AppSettings
import com.brownstar.rabbit.media.RabbitMediaService
import com.brownstar.rabbit.media.toMediaItem
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

data class TechnicalInfo(
    val format: String,
    val bitrate: String,
    val sampleRate: String,
    val size: String,
    val path: String,
    val isLossless: Boolean = false,
    val isHiRes: Boolean = false,
    val channelConfig: String = "Unknown"
)

class MusicViewModel(
    private val repository: MusicRepository,
    context: Context
) : ViewModel() {

    private val settingsManager = SettingsManager(context)
    val appSettings: StateFlow<AppSettings> = settingsManager.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _albums = MutableStateFlow<List<Album>>(emptyList())
    val albums: StateFlow<List<Album>> = _albums.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _currentSong = MutableStateFlow<Song?>(null)
    val currentSong: StateFlow<Song?> = _currentSong.asStateFlow()

    private val _technicalInfo = MutableStateFlow<TechnicalInfo?>(null)
    val technicalInfo: StateFlow<TechnicalInfo?> = _technicalInfo.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _repeatMode = MutableStateFlow(Player.REPEAT_MODE_ALL)
    val repeatMode: StateFlow<Int> = _repeatMode.asStateFlow()

    private val _shuffleModeEnabled = MutableStateFlow(false)
    val shuffleModeEnabled: StateFlow<Boolean> = _shuffleModeEnabled.asStateFlow()

    private val _audioSessionId = MutableStateFlow(0)
    val audioSessionId: StateFlow<Int> = _audioSessionId.asStateFlow()

    private val _playbackProgress = MutableStateFlow(0L)
    val playbackProgress: StateFlow<Long> = _playbackProgress.asStateFlow()

    private val _playbackDuration = MutableStateFlow(0L)
    val playbackDuration: StateFlow<Long> = _playbackDuration.asStateFlow()

    private val _isLyricsEnabled = MutableStateFlow(false)
    val isLyricsEnabled: StateFlow<Boolean> = _isLyricsEnabled.asStateFlow()

    private val _deleteRequest = MutableStateFlow<android.app.PendingIntent?>(null)
    val deleteRequest: StateFlow<android.app.PendingIntent?> = _deleteRequest.asStateFlow()

    private var controllerFuture: ListenableFuture<MediaController>
    private val controller: MediaController?
        get() = if (controllerFuture.isDone) controllerFuture.get() else null

    init {
        val sessionToken = SessionToken(context, ComponentName(context, RabbitMediaService::class.java))
        controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture.addListener({
            setupController()
        }, MoreExecutors.directExecutor())

        viewModelScope.launch {
            repository.allSongs.collect {
                _songs.value = it
            }
        }

        viewModelScope.launch {
            repository.allAlbums.collect {
                _albums.value = it
            }
        }

        viewModelScope.launch {
            while (isActive) {
                controller?.let {
                    _playbackProgress.value = it.currentPosition
                    _playbackDuration.value = it.duration.coerceAtLeast(0L)
                }
                delay(1000)
            }
        }
    }

    private fun setupController() {
        val controller = controller ?: return
        controller.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                updateCurrentSong(mediaItem)
            }

            override fun onMediaMetadataChanged(mediaMetadata: androidx.media3.common.MediaMetadata) {
                updateCurrentSong(controller.currentMediaItem)
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                _repeatMode.value = repeatMode
            }

            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                _shuffleModeEnabled.value = shuffleModeEnabled
            }

            @androidx.media3.common.util.UnstableApi
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                _audioSessionId.value = audioSessionId
            }
        })
        updateCurrentSong(controller.currentMediaItem)
        _isPlaying.value = controller.isPlaying
        _repeatMode.value = controller.repeatMode
        _shuffleModeEnabled.value = controller.shuffleModeEnabled
        _playbackDuration.value = controller.duration.coerceAtLeast(0L)
    }

    fun getSongsByAlbum(albumId: Long) = repository.getSongsByAlbum(albumId)

    fun getSongsByArtist(artistName: String) = repository.getSongsByArtist(artistName)

    fun getAlbumById(albumId: Long, onResult: (Album?) -> Unit) {
        viewModelScope.launch {
            val result = repository.getAlbumById(albumId)
            onResult(result)
        }
    }

    fun seekTo(position: Long) {
        controller?.seekTo(position)
    }

    fun toggleRepeatMode() {
        val controller = controller ?: return
        val nextMode = when (controller.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_OFF
            else -> Player.REPEAT_MODE_OFF
        }
        controller.repeatMode = nextMode
    }

    fun toggleShuffleMode() {
        val controller = controller ?: return
        controller.shuffleModeEnabled = !controller.shuffleModeEnabled
    }

    private fun updateCurrentSong(mediaItem: MediaItem?) {
        val mediaId = mediaItem?.mediaId
        val song = _songs.value.find { it.id.toString() == mediaId }
        _currentSong.value = song
        updateTechnicalInfo(song)
    }

    private fun updateTechnicalInfo(song: Song?) {
        if (song == null) {
            _technicalInfo.value = null
            return
        }

        // Use stored info if available, otherwise try to extract it
        val format = song.mimeType.substringAfter("/")
        val size = String.format(Locale.getDefault(), "%.2f MB", song.size / (1024.0 * 1024.0))
        val isLossless = song.isLossless
        val isHiRes = song.isHiRes

        if (song.bitrate > 0 && song.sampleRate > 0) {
            val bitrate = "${song.bitrate / 1000} kbps"
            val sampleRate = "${song.sampleRate} Hz"
            val channelConfig = when (song.channels) {
                1 -> "MONO"
                2 -> "STEREO"
                in 3..Int.MAX_VALUE -> "SURROUND"
                else -> "Unknown"
            }

            _technicalInfo.value = TechnicalInfo(
                format = format.uppercase(Locale.getDefault()),
                bitrate = bitrate,
                sampleRate = sampleRate,
                size = size,
                path = song.path,
                isLossless = isLossless,
                isHiRes = isHiRes,
                channelConfig = channelConfig
            )
        } else {
            // Fallback to retriever if database fields are missing (e.g. old scan)
            viewModelScope.launch(Dispatchers.IO) {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(song.path)
                    val bitrateStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)
                    val bitrate = bitrateStr?.let {
                        "${it.toInt() / 1000} kbps"
                    } ?: "Unknown"
                    
                    var sampleRate = "Unknown"
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        sampleRate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_SAMPLERATE)?.let {
                            "${it} Hz"
                        } ?: "Unknown"
                    }
                    
                    var numChannels = 0
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        // METADATA_KEY_NUM_CHANNELS = 43
                        numChannels = retriever.extractMetadata(43)?.toIntOrNull() ?: 0
                    }
                    val channelConfig = when (numChannels) {
                        1 -> "MONO"
                        2 -> "STEREO"
                        in 3..Int.MAX_VALUE -> "SURROUND"
                        else -> "Unknown"
                    }

                    _technicalInfo.value = TechnicalInfo(
                        format = format.uppercase(Locale.getDefault()),
                        bitrate = bitrate,
                        sampleRate = sampleRate,
                        size = size,
                        path = song.path,
                        isLossless = isLossless,
                        isHiRes = isHiRes,
                        channelConfig = channelConfig
                    )
                } catch (e: Exception) {
                    _technicalInfo.value = TechnicalInfo(
                        format = format.uppercase(Locale.getDefault()),
                        bitrate = "Unknown",
                        sampleRate = "Unknown",
                        size = size,
                        path = song.path,
                        isLossless = isLossless,
                        isHiRes = isHiRes,
                        channelConfig = "Unknown"
                    )
                } finally {
                    retriever.release()
                }
            }
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun playSong(song: Song, playlist: List<Song>) {
        val controller = controller ?: return
        
        val mediaItems = playlist.map { it.toMediaItem() }
        val index = playlist.indexOfFirst { it.id == song.id }.coerceAtLeast(0)

        controller.setMediaItems(mediaItems, index, 0)
        controller.prepare()
        controller.play()
    }

    fun togglePlayPause() {
        val controller = controller ?: return
        if (controller.playbackState == Player.STATE_IDLE) {
            controller.prepare()
        }
        if (controller.isPlaying) {
            controller.pause()
        } else {
            controller.play()
        }
    }

    fun setShowTechnicalInfo(show: Boolean) {
        viewModelScope.launch {
            settingsManager.setShowTechnicalInfo(show)
        }
    }

    fun toggleLyrics() {
        _isLyricsEnabled.value = !_isLyricsEnabled.value
    }

    fun searchLyricsOnline(context: Context, song: Song) {
        val query = if (song.title != "Unknown" && song.artist != "Unknown") {
            "${song.title} ${song.artist} lyrics"
        } else {
            val fileName = song.path.substringAfterLast("/").substringBeforeLast(".")
            "$fileName lyrics"
        }
        val encodedQuery = java.net.URLEncoder.encode(query, "UTF-8")
        val url = "https://www.google.com/search?q=$encodedQuery"
        val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))
        context.startActivity(intent)
    }

    fun playNext() {
        controller?.seekToNext()
    }

    fun playPrevious() {
        controller?.seekToPrevious()
    }

    fun deleteSong(context: Context, song: Song) {
        viewModelScope.launch {
            try {
                val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, song.id)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val uris = listOf(uri)
                    val pendingIntent = MediaStore.createDeleteRequest(context.contentResolver, uris)
                    _deleteRequest.value = pendingIntent
                } else {
                    try {
                        context.contentResolver.delete(uri, null, null)
                        onSongDeleted(song)
                    } catch (e: Exception) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && e is android.app.RecoverableSecurityException) {
                            _deleteRequest.value = e.userAction.actionIntent
                        } else {
                            e.printStackTrace()
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun onSongDeleted(song: Song) {
        viewModelScope.launch {
            repository.deleteSong(song)
            _songs.value = _songs.value.filter { it.id != song.id }
            _albums.value = _albums.value.map { album ->
                if (album.id == song.albumId) {
                    album.copy(trackCount = album.trackCount - 1)
                } else album
            }.filter { it.trackCount > 0 }
            _deleteRequest.value = null
        }
    }

    fun clearDeleteRequest() {
        _deleteRequest.value = null
    }

    fun forceRefreshAllMetadata(context: Context) {
        viewModelScope.launch {
            repository.refreshLibrary()
        }
    }

    suspend fun refreshLibrary() {
        repository.refreshLibrary()
    }

    fun scanLibrary() {
        viewModelScope.launch {
            repository.refreshLibrary()
        }
    }

    fun openEqualizer(context: Context) {
        val audioSessionId = _audioSessionId.value
        val intent = Intent(android.media.audiofx.AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL).apply {
            putExtra(android.media.audiofx.AudioEffect.EXTRA_AUDIO_SESSION, audioSessionId)
            putExtra(android.media.audiofx.AudioEffect.EXTRA_PACKAGE_NAME, context.packageName)
            putExtra(android.media.audiofx.AudioEffect.EXTRA_CONTENT_TYPE, android.media.audiofx.AudioEffect.CONTENT_TYPE_MUSIC)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            // System equalizer not found
        }
    }

    override fun onCleared() {
        super.onCleared()
        MediaController.releaseFuture(controllerFuture)
    }
}
