package com.brownstar.rabbit.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.brownstar.rabbit.data.MusicDatabase
import com.brownstar.rabbit.data.repository.MusicRepository
import com.brownstar.rabbit.scanner.MediaScanner

class MusicViewModelFactory(private val context: Context) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MusicViewModel::class.java)) {
            val database = MusicDatabase.getDatabase(context)
            val mediaScanner = MediaScanner(context)
            val repository = MusicRepository.getInstance(
                database.songDao(),
                database.albumDao(),
                mediaScanner
            )
            
            @Suppress("UNCHECKED_CAST")
            return MusicViewModel(repository, context) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
