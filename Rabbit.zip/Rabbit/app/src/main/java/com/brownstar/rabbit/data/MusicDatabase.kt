package com.brownstar.rabbit.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.brownstar.rabbit.data.dao.AlbumDao
import com.brownstar.rabbit.data.dao.SongDao
import com.brownstar.rabbit.data.model.Album
import com.brownstar.rabbit.data.model.Playlist
import com.brownstar.rabbit.data.model.PlaylistSongCrossRef
import com.brownstar.rabbit.data.model.Song

@Database(
    entities = [Song::class, Album::class, Playlist::class, PlaylistSongCrossRef::class],
    version = 7,
    exportSchema = false
)
abstract class MusicDatabase : RoomDatabase() {
    abstract fun songDao(): SongDao
    abstract fun albumDao(): AlbumDao

    companion object {
        @Volatile
        private var INSTANCE: MusicDatabase? = null

        fun getDatabase(context: Context): MusicDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MusicDatabase::class.java,
                    "music_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
