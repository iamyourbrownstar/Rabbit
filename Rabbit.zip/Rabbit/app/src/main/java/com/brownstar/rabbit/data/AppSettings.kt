package com.brownstar.rabbit.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "app_settings")

data class AppSettings(
    val showTechnicalInfo: Boolean = true
)

class SettingsManager(private val context: Context) {
    companion object {
        private val SHOW_TECHNICAL_INFO = booleanPreferencesKey("show_technical_info")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { preferences ->
        AppSettings(
            showTechnicalInfo = preferences[SHOW_TECHNICAL_INFO] ?: true
        )
    }

    suspend fun setShowTechnicalInfo(show: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[SHOW_TECHNICAL_INFO] = show
        }
    }
}
