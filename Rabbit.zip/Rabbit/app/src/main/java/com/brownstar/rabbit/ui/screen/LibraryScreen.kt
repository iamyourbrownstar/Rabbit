package com.brownstar.rabbit.ui.screen

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.brownstar.rabbit.R
import com.brownstar.rabbit.data.model.Album
import com.brownstar.rabbit.data.model.Song
import com.brownstar.rabbit.ui.viewmodel.MusicViewModel
import com.brownstar.rabbit.util.MusicUtils
import com.brownstar.rabbit.util.SongAction
import com.brownstar.rabbit.util.SongActionHandler
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    viewModel: MusicViewModel,
    onSongClick: (Song) -> Unit,
    onAlbumClick: (Long) -> Unit,
    onArtistClick: (String) -> Unit,
    onSettingsClick: () -> Unit
) {
    val songs by viewModel.songs.collectAsState()
    val albums by viewModel.albums.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Songs", "Albums", "Artists")
    
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val filteredSongs = remember(songs, searchQuery) {
        if (searchQuery.isEmpty()) songs else songs.filter { 
            it.title.contains(searchQuery, ignoreCase = true) || it.artist.contains(searchQuery, ignoreCase = true)
        }
    }

    val filteredAlbums = remember(albums, searchQuery) {
        if (searchQuery.isEmpty()) albums else albums.filter {
            it.title.contains(searchQuery, ignoreCase = true) || it.artist.contains(searchQuery, ignoreCase = true)
        }
    }

    val artists = remember(songs) {
        songs.map { it.artist }.distinct().sorted()
    }
    
    val filteredArtists = remember(artists, searchQuery) {
        if (searchQuery.isEmpty()) artists else artists.filter {
            it.contains(searchQuery, ignoreCase = true)
        }
    }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = { Text("Rabbit Music", fontWeight = FontWeight.Bold) },
                    actions = {
                        var showMenu by remember { mutableStateOf(false) }
                        IconButton(onClick = { showMenu = true }) {
                            Icon(Icons.Rounded.MoreVert, contentDescription = "More")
                        }
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Equalizer") },
                                onClick = {
                                    showMenu = false
                                    viewModel.openEqualizer(context)
                                },
                                leadingIcon = { Icon(Icons.Rounded.GraphicEq, contentDescription = null) }
                            )
                            DropdownMenuItem(
                                text = { Text("Refresh Library") },
                                onClick = {
                                    showMenu = false
                                    scope.launch {
                                        viewModel.refreshLibrary()
                                    }
                                },
                                leadingIcon = { Icon(Icons.Rounded.Refresh, contentDescription = null) }
                            )
                            DropdownMenuItem(
                                text = { Text("Settings") },
                                onClick = {
                                    showMenu = false
                                    onSettingsClick()
                                },
                                leadingIcon = { Icon(Icons.Rounded.Settings, contentDescription = null) }
                            )
                        }
                    }
                )
                SearchBar(
                    query = searchQuery,
                    onQueryChange = { viewModel.updateSearchQuery(it) },
                    onSearch = { /* Handle search action if needed */ },
                    active = false,
                    onActiveChange = { },
                    placeholder = { Text("Search songs, albums, artists...") },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Clear")
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) { }

                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.primary,
                    indicator = { tabPositions ->
                        if (selectedTab < tabPositions.size) {
                            TabRowDefaults.SecondaryIndicator(
                                modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                                color = Color.Red
                            )
                        }
                    }
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = { 
                                Text(
                                    text = title,
                                    color = if (selectedTab == index) Color.Red else MaterialTheme.colorScheme.onSurfaceVariant,
                                    style = MaterialTheme.typography.titleSmall
                                )
                            }
                        )
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            when (selectedTab) {
                0 -> {
                    if (filteredSongs.isEmpty()) {
                        item {
                            Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text("No songs found")
                            }
                        }
                    } else {
                        items(filteredSongs) { song ->
                            SongItem(
                                song = song, 
                                onClick = { onSongClick(song) },
                                onAction = { action -> 
                                    SongActionHandler.handleSongAction(context, action, song, viewModel)
                                }
                            )
                        }
                    }
                }
                1 -> {
                    if (filteredAlbums.isEmpty()) {
                        item {
                            Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text("No albums found")
                            }
                        }
                    } else {
                        items(filteredAlbums) { album ->
                            AlbumItem(album = album, onClick = { onAlbumClick(album.id) })
                        }
                    }
                }
                2 -> {
                    if (filteredArtists.isEmpty()) {
                        item {
                            Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text("No artists found")
                            }
                        }
                    } else {
                        items(filteredArtists) { artist ->
                            ArtistItem(artist = artist, onClick = { onArtistClick(artist) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LibraryQualityBadge(
    text: String,
    containerColor: Color = MaterialTheme.colorScheme.surfaceVariant,
    contentColor: Color = MaterialTheme.colorScheme.onSurfaceVariant
) {
    Surface(
        color = containerColor,
        shape = CircleShape
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
            color = contentColor
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SongItem(song: Song, onClick: () -> Unit, onAction: (SongAction) -> Unit) {
    var showMenu by remember { mutableStateOf(false) }

    ListItem(
        modifier = Modifier.combinedClickable(
            onClick = onClick,
            onLongClick = { showMenu = true }
        ),
        headlineContent = {
            Text(
                text = song.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium
            )
        },
        supportingContent = {
            Column {
                Text(
                    text = "${song.artist} • ${MusicUtils.formatDuration(song.duration)}",
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium
                )
                
                Row(
                    modifier = Modifier.padding(top = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (song.isHiRes) {
                        LibraryQualityBadge("HI-RES", Color(0xFFFFD700).copy(alpha = 0.2f), Color(0xFFFFD700))
                        Spacer(modifier = Modifier.width(4.dp))
                    } else if (song.isLossless) {
                        LibraryQualityBadge("LOSSLESS", MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer)
                        Spacer(modifier = Modifier.width(4.dp))
                    }

                    if (song.isAtmos) {
                        LibraryQualityBadge("ATMOS", Color(0xFF007AFF).copy(alpha = 0.2f), Color(0xFF007AFF))
                        Spacer(modifier = Modifier.width(4.dp))
                    } else if (song.isDolby) {
                        LibraryQualityBadge("DOLBY", Color(0xFF007AFF).copy(alpha = 0.2f), Color(0xFF007AFF))
                        Spacer(modifier = Modifier.width(4.dp))
                    }

                    if (song.isDtsX) {
                        LibraryQualityBadge("DTS:X", Color(0xFFFF3B30).copy(alpha = 0.2f), Color(0xFFFF3B30))
                        Spacer(modifier = Modifier.width(4.dp))
                    } else if (song.isDts) {
                        LibraryQualityBadge("DTS", Color(0xFFFF3B30).copy(alpha = 0.2f), Color(0xFFFF3B30))
                        Spacer(modifier = Modifier.width(4.dp))
                    }

                    val channelText = when (song.channels) {
                        1 -> "MONO"
                        2 -> "STEREO"
                        else -> if (song.channels > 2) "SURROUND" else null
                    }
                    if (channelText != null) {
                        LibraryQualityBadge(channelText)
                    }
                }
            }
        },
        leadingContent = {
            AsyncImage(
                model = "content://media/external/audio/albumart/${song.albumId}",
                contentDescription = "Album Art",
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape),
                contentScale = ContentScale.Crop,
                error = null
            )
        },
        trailingContent = {
            Box {
                IconButton(onClick = { showMenu = true }) {
                    Icon(
                        imageVector = Icons.Rounded.MoreVert,
                        contentDescription = "More Options",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Share") },
                        onClick = {
                            onAction(SongAction.SHARE)
                            showMenu = false
                        },
                        leadingIcon = { Icon(Icons.Rounded.Share, contentDescription = null) }
                    )
                    DropdownMenuItem(
                        text = { Text("Set as Ringtone") },
                        onClick = {
                            onAction(SongAction.SET_AS_RINGTONE)
                            showMenu = false
                        },
                        leadingIcon = { Icon(Icons.Rounded.NotificationsActive, contentDescription = null) }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
                        onClick = {
                            onAction(SongAction.DELETE)
                            showMenu = false
                        },
                        leadingIcon = { Icon(Icons.Rounded.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                    )
                }
            }
        }
    )
}

@Composable
fun AlbumItem(album: Album, onClick: () -> Unit) {
    ListItem(
        modifier = Modifier.clickable(onClick = onClick),
        headlineContent = {
            Text(album.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
        },
        supportingContent = {
            Text("${album.artist} • ${album.trackCount} tracks", maxLines = 1, overflow = TextOverflow.Ellipsis)
        },
        leadingContent = {
            AsyncImage(
                model = "content://media/external/audio/albumart/${album.id}",
                contentDescription = "Album Art",
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape),
                contentScale = ContentScale.Crop
            )
        }
    )
}

@Composable
fun ArtistItem(artist: String, onClick: () -> Unit) {
    ListItem(
        modifier = Modifier.clickable(onClick = onClick),
        headlineContent = {
            Text(artist, maxLines = 1, overflow = TextOverflow.Ellipsis)
        },
        leadingContent = {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Person, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        }
    )
}
