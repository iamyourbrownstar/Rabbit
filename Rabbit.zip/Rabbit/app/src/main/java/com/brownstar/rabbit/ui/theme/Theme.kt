package com.brownstar.rabbit.ui.theme

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.drawable.toBitmap
import androidx.palette.graphics.Palette
import coil.ImageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult

private val DarkColorScheme = darkColorScheme(
    primary = Purple80,
    secondary = PurpleGrey80,
    tertiary = Pink80
)

private val LightColorScheme = lightColorScheme(
    primary = Purple40,
    secondary = PurpleGrey40,
    tertiary = Pink40
)

@Composable
fun RabbitTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    artworkUri: String? = null,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    var seedColor by remember { mutableStateOf<Color?>(null) }

    LaunchedEffect(artworkUri) {
        if (artworkUri != null) {
            val loader = ImageLoader(context)
            val request = ImageRequest.Builder(context)
                .data(artworkUri)
                .allowHardware(false)
                .build()

            val result = loader.execute(request)
            if (result is SuccessResult) {
                val bitmap = (result.drawable as BitmapDrawable).bitmap
                val palette = Palette.from(bitmap).generate()
                val dominantColor = palette.getDominantColor(Color.Transparent.toArgb())
                if (dominantColor != Color.Transparent.toArgb()) {
                    seedColor = Color(dominantColor)
                }
            }
        } else {
            seedColor = null
        }
    }

    val colorScheme = when {
        seedColor != null -> {
            if (darkTheme) dynamicDarkColorScheme(context).copy(primary = seedColor!!) 
            else dynamicLightColorScheme(context).copy(primary = seedColor!!)
            // Note: For a truly vibrant experience, we should use Material Color Utilities to generate a full scheme from seed.
            // But for now, we'll use dynamic color as base and override primary if seed is available.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && dynamicColor) {
                 if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
            } else {
                 if (darkTheme) DarkColorScheme else LightColorScheme
            }
        }
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    // Since we want VIBRANT and ENERGETIC, let's refine the color scheme selection
    val finalColorScheme = if (seedColor != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val base = if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        base.copy(
            primary = seedColor!!,
            primaryContainer = seedColor!!.copy(alpha = 0.3f),
            onPrimaryContainer = if (darkTheme) Color.White else Color.Black
        )
    } else colorScheme

    MaterialTheme(
        colorScheme = finalColorScheme,
        typography = Typography,
        content = content
    )
}
