package com.brownstar.rabbit.media

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import com.brownstar.rabbit.data.model.Song

fun Song.toMediaItem(): MediaItem {
    val artworkUri = Uri.parse("content://media/external/audio/albumart/$albumId")
    
    val metadata = MediaMetadata.Builder()
        .setTitle(title)
        .setArtist(artist)
        .setAlbumTitle(album)
        .setArtworkUri(artworkUri)
        .setIsPlayable(true)
        .build()

    return MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(path)
        .setMediaMetadata(metadata)
        .build()
}
