package com.brownstar.rabbit.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Index

@Entity(
    tableName = "songs",
    indices = [Index(value = ["path"], unique = true)]
)
data class Song(
    @PrimaryKey val id: Long, // MediaStore ID
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val path: String,
    val albumId: Long,
    val trackNumber: Int,
    val year: Int,
    val dateAdded: Long,
    val mimeType: String,
    val size: Long,
    val sampleRate: Int = 0,
    val channels: Int = 0,
    val bitrate: Long = 0,
    val bitDepth: Int = 0,
    val lyrics: String? = null
) {
    val isLossless: Boolean
        get() = mimeType.contains("flac", ignoreCase = true) || 
                mimeType.contains("wav", ignoreCase = true) || 
                mimeType.contains("alac", ignoreCase = true) ||
                path.endsWith(".flac", ignoreCase = true) ||
                path.endsWith(".wav", ignoreCase = true) ||
                path.endsWith(".alac", ignoreCase = true) ||
                path.endsWith(".dsf", ignoreCase = true) ||
                path.endsWith(".dff", ignoreCase = true)

    val isHiRes: Boolean
        get() = sampleRate > 48000 || bitDepth > 16 || bitrate > 1411200 || path.endsWith(".dsf", ignoreCase = true) || path.endsWith(".dff", ignoreCase = true)

    val isAtmos: Boolean
        get() = mimeType.contains("atmos", ignoreCase = true) || path.contains("atmos", ignoreCase = true)

    val isDolbyDigital: Boolean
        get() = mimeType.contains("ac3", ignoreCase = true) || 
                mimeType.contains("ec3", ignoreCase = true) ||
                path.endsWith(".ac3", ignoreCase = true) ||
                path.endsWith(".ec3", ignoreCase = true)

    val isDolby: Boolean
        get() = isAtmos || isDolbyDigital || path.contains("dolby", ignoreCase = true)

    val isDtsX: Boolean
        get() = path.contains("dts-x", ignoreCase = true) || path.contains("dtsx", ignoreCase = true)

    val isDts: Boolean
        get() = isDtsX || mimeType.contains("dts", ignoreCase = true) || path.contains("dts", ignoreCase = true) || path.endsWith(".dts", ignoreCase = true)
}
