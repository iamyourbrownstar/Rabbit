package com.brownstar.rabbit.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "equalizer_settings")

data class EqualizerSettings(
    val bassBoost: Int = 0,
    val preamp: Int = 0,
    val bandLevels: Map<Int, Int> = emptyMap()
)

class EqualizerPreferences(private val context: Context) {
    private val SETTINGS_KEY = stringPreferencesKey("eq_settings")

    val settings: Flow<EqualizerSettings> = context.dataStore.data.map { preferences ->
        val json = preferences[SETTINGS_KEY] ?: return@map EqualizerSettings()
        // Simple manual parsing since we don't have Moshi configured for this yet
        // In a real app, use Moshi or Kotlin Serialization
        parseSettings(json)
    }

    suspend fun saveSettings(settings: EqualizerSettings) {
        context.dataStore.edit { preferences ->
            preferences[SETTINGS_KEY] = serializeSettings(settings)
        }
    }

    private fun serializeSettings(settings: EqualizerSettings): String {
        val bands = settings.bandLevels.entries.joinToString(",") { "${it.key}:${it.value}" }
        return "${settings.bassBoost}|${settings.preamp}|$bands"
    }

    private fun parseSettings(data: String): EqualizerSettings {
        return try {
            val parts = data.split("|")
            val bassBoost = parts[0].toInt()
            val preamp = parts[1].toInt()
            val bands = if (parts.size > 2 && parts[2].isNotEmpty()) {
                parts[2].split(",").associate {
                    val kv = it.split(":")
                    kv[0].toInt() to kv[1].toInt()
                }
            } else emptyMap()
            EqualizerSettings(bassBoost, preamp, bands)
        } catch (e: Exception) {
            EqualizerSettings()
        }
    }
}
