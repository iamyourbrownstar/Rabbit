package com.brownstar.rabbit

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.brownstar.rabbit.ui.navigation.Screen
import com.brownstar.rabbit.ui.screen.AlbumDetailScreen
import com.brownstar.rabbit.ui.screen.ArtistDetailScreen
import com.brownstar.rabbit.ui.screen.LibraryScreen
import com.brownstar.rabbit.ui.screen.MiniPlayer
import com.brownstar.rabbit.ui.screen.NowPlayingScreen
import com.brownstar.rabbit.ui.screen.SettingsScreen
import com.brownstar.rabbit.ui.theme.RabbitTheme
import com.brownstar.rabbit.ui.viewmodel.MusicViewModel
import com.brownstar.rabbit.ui.viewmodel.MusicViewModelFactory
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: MusicViewModel = viewModel(
                factory = MusicViewModelFactory(applicationContext)
            )
            
            val currentSong by viewModel.currentSong.collectAsState()
            val artworkUri = if (currentSong != null) {
                "content://media/external/audio/albumart/${currentSong?.albumId}"
            } else {
                null
            }

            RabbitTheme(artworkUri = artworkUri) {
                MainContent(viewModel)
            }
        }
    }
}

@Composable
fun MainContent(viewModel: MusicViewModel) {
    val navController = rememberNavController()
    val scope = rememberCoroutineScope()
    val currentSong by viewModel.currentSong.collectAsState()
    val deleteRequest by viewModel.deleteRequest.collectAsState()
    
    val deleteLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            // After successful system deletion, we need to know which song it was.
            // For now, let's refresh the whole library or rely on the fact that
            // users will only delete one at a time.
            // Ideally we'd pass the song along, but let's refresh.
            viewModel.scanLibrary()
        }
        viewModel.clearDeleteRequest()
    }

    LaunchedEffect(deleteRequest) {
        deleteRequest?.let { pendingIntent ->
            deleteLauncher.launch(IntentSenderRequest.Builder(pendingIntent).build())
        }
    }
    
    val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        arrayOf(
            Manifest.permission.READ_MEDIA_AUDIO,
            Manifest.permission.POST_NOTIFICATIONS
        )
    } else {
        arrayOf(
            Manifest.permission.READ_EXTERNAL_STORAGE
        )
    }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            viewModel.scanLibrary()
        }
    }

    LaunchedEffect(Unit) {
        launcher.launch(permissions)
    }

    val currentBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = currentBackStackEntry?.destination?.route
    val isNowPlayingVisible = currentRoute == Screen.NowPlaying.route

    Scaffold(
        bottomBar = {
            if (!isNowPlayingVisible && currentSong != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    MiniPlayer(
                        viewModel = viewModel,
                        onClick = {
                            navController.navigate(Screen.NowPlaying.route)
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Library.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Library.route) {
                LibraryScreen(
                    viewModel = viewModel,
                    onSongClick = { song ->
                        viewModel.playSong(song, viewModel.songs.value)
                    },
                    onAlbumClick = { albumId ->
                        navController.navigate(Screen.AlbumDetail.createRoute(albumId))
                    },
                    onArtistClick = { artistName ->
                        navController.navigate(Screen.ArtistDetail.createRoute(artistName))
                    },
                    onSettingsClick = {
                        navController.navigate(Screen.Settings.route)
                    }
                )
            }
            composable(Screen.Settings.route) {
                SettingsScreen(
                    viewModel = viewModel,
                    onBackClick = {
                        navController.popBackStack()
                    }
                )
            }
            composable(Screen.NowPlaying.route) {
                NowPlayingScreen(
                    viewModel = viewModel,
                    onBackClick = {
                        navController.popBackStack()
                    }
                )
            }
            composable(Screen.AlbumDetail.route) { backStackEntry ->
                val albumId = backStackEntry.arguments?.getString("albumId")?.toLongOrNull() ?: return@composable
                AlbumDetailScreen(
                    albumId = albumId,
                    viewModel = viewModel,
                    onBackClick = { navController.popBackStack() },
                    onSongClick = { song, playlist ->
                        viewModel.playSong(song, playlist)
                    }
                )
            }
            composable(Screen.ArtistDetail.route) { backStackEntry ->
                val artistName = backStackEntry.arguments?.getString("artistName") ?: return@composable
                ArtistDetailScreen(
                    artistName = artistName,
                    viewModel = viewModel,
                    onBackClick = { navController.popBackStack() },
                    onSongClick = { song, playlist ->
                        viewModel.playSong(song, playlist)
                    }
                )
            }
        }
    }
}
