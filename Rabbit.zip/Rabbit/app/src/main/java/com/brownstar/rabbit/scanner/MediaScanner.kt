package com.brownstar.rabbit.scanner

import android.content.ContentUris
import android.content.Context
import android.media.MediaMetadataRetriever
import android.os.Build
import android.provider.MediaStore
import com.brownstar.rabbit.data.model.Album
import com.brownstar.rabbit.data.model.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class MediaScanner(private val context: Context) {

    suspend fun scanAudioFiles(): Pair<List<Song>, List<Album>> = withContext(Dispatchers.IO) {
        val songs = mutableListOf<Song>()
        val albumsMap = mutableMapOf<Long, Album>()

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.SIZE
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            selection,
            null,
            sortOrder
        )?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val dataColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val trackColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
            val yearColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
            val dateAddedColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val mimeTypeColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
            val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idColumn)
                val title = cursor.getString(titleColumn) ?: "Unknown"
                val artist = cursor.getString(artistColumn) ?: "Unknown Artist"
                val albumTitle = cursor.getString(albumColumn) ?: "Unknown Album"
                val albumId = cursor.getLong(albumIdColumn)
                val duration = cursor.getLong(durationColumn)
                val path = cursor.getString(dataColumn)
                val trackNumber = cursor.getInt(trackColumn)
                val year = cursor.getInt(yearColumn)
                val dateAdded = cursor.getLong(dateAddedColumn)
                val mimeType = cursor.getString(mimeTypeColumn) ?: "audio/*"
                val size = cursor.getLong(sizeColumn)

                var sampleRate = 0
                var channels = 0
                var bitrate = 0L
                var bitDepth = 0
                var lyrics: String? = null
                
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(path)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        sampleRate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_SAMPLERATE)?.toIntOrNull() ?: 0
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        // METADATA_KEY_NUM_CHANNELS = 43
                        channels = retriever.extractMetadata(43)?.toIntOrNull() ?: 0
                    }
                    bitrate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull() ?: 0L
                    
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        // METADATA_KEY_BITS_PER_SAMPLE = 39
                        bitDepth = retriever.extractMetadata(39)?.toIntOrNull() ?: 0
                    }

                    // Try to extract lyrics
                    // METADATA_KEY_LYRIC = 1000 on many Android devices for USLT
                    lyrics = retriever.extractMetadata(1000)
                } catch (e: Exception) {
                    android.util.Log.e("MediaScanner", "Error extracting metadata for $path", e)
                } finally {
                    retriever.release()
                }

                var finalTitle = title
                var finalArtist = artist
                var finalAlbum = albumTitle

                val song = Song(
                    id = id,
                    title = finalTitle,
                    artist = finalArtist,
                    album = finalAlbum,
                    duration = duration,
                    path = path,
                    albumId = albumId,
                    trackNumber = trackNumber,
                    year = year,
                    dateAdded = dateAdded,
                    mimeType = mimeType,
                    size = size,
                    sampleRate = sampleRate,
                    channels = channels,
                    bitrate = bitrate,
                    bitDepth = bitDepth,
                    lyrics = lyrics
                )
                songs.add(song)

                if (!albumsMap.containsKey(albumId)) {
                    val albumArtUri = ContentUris.withAppendedId(
                        android.net.Uri.parse("content://media/external/audio/albumart"),
                        albumId
                    ).toString()
                    
                    albumsMap[albumId] = Album(
                        id = albumId,
                        title = albumTitle,
                        artist = artist,
                        year = year,
                        trackCount = 0, // Will be updated later if needed or calculated by Room
                        albumArtUri = albumArtUri
                    )
                }
            }
        }

        Pair(songs, albumsMap.values.toList())
    }
}
