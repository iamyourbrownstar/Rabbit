package com.brownstar.rabbit.data.repository

import com.brownstar.rabbit.data.dao.AlbumDao
import com.brownstar.rabbit.data.dao.SongDao
import com.brownstar.rabbit.data.model.Album
import com.brownstar.rabbit.data.model.Song
import com.brownstar.rabbit.scanner.MediaScanner
import kotlinx.coroutines.flow.Flow

class MusicRepository(
    private val songDao: SongDao,
    private val albumDao: AlbumDao,
    private val mediaScanner: MediaScanner
) {
    val allSongs: Flow<List<Song>> = songDao.getAllSongs()
    val allAlbums: Flow<List<Album>> = albumDao.getAllAlbums()

    suspend fun refreshLibrary() {
        val (songs, albums) = mediaScanner.scanAudioFiles()
        songDao.insertSongs(songs)
        albumDao.insertAlbums(albums)
        
        // Cleanup
        val paths = songs.map { it.path }
        songDao.deleteSongsNotInList(paths)
        albumDao.deleteOrphanedAlbums()
    }

    suspend fun getSongByPath(path: String): Song? {
        return songDao.getSongByPath(path)
    }

    suspend fun updateSong(song: Song) {
        songDao.insertSongs(listOf(song))
    }

    suspend fun updateAlbum(album: Album) {
        albumDao.insertAlbum(album)
    }

    fun getSongsByAlbum(albumId: Long): Flow<List<Song>> = songDao.getSongsByAlbum(albumId)
    
    fun getSongsByArtist(artistName: String): Flow<List<Song>> = songDao.getSongsByArtist(artistName)
    
    suspend fun getAlbumById(albumId: Long): Album? = albumDao.getAlbumById(albumId)

    suspend fun deleteSong(song: Song) {
        songDao.deleteSong(song)
    }

    companion object {
        @Volatile
        private var INSTANCE: MusicRepository? = null

        fun getInstance(
            songDao: SongDao,
            albumDao: AlbumDao,
            mediaScanner: MediaScanner
        ): MusicRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = MusicRepository(songDao, albumDao, mediaScanner)
                INSTANCE = instance
                instance
            }
        }
    }
}
