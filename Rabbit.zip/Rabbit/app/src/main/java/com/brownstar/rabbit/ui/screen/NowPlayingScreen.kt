package com.brownstar.rabbit.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Lyrics
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.brownstar.rabbit.data.model.Song
import com.brownstar.rabbit.ui.viewmodel.MusicViewModel
import com.brownstar.rabbit.util.MusicUtils
import com.brownstar.rabbit.util.SongAction
import com.brownstar.rabbit.util.SongActionHandler

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun NowPlayingScreen(
    viewModel: MusicViewModel,
    onBackClick: () -> Unit
) {
    val currentSong by viewModel.currentSong.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val repeatMode by viewModel.repeatMode.collectAsState()
    val shuffleModeEnabled by viewModel.shuffleModeEnabled.collectAsState()
    val playbackProgress by viewModel.playbackProgress.collectAsState()
    val playbackDuration by viewModel.playbackDuration.collectAsState()
    val technicalInfo by viewModel.technicalInfo.collectAsState()
    val isLyricsEnabled by viewModel.isLyricsEnabled.collectAsState()
    val appSettings by viewModel.appSettings.collectAsState()

    var showMenu by remember { mutableStateOf(false) }
    var showTechnicalInfo by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val title = currentSong?.title ?: "No Song Playing"
    val artist = currentSong?.artist ?: "Unknown Artist"
    val artworkUri = "content://media/external/audio/albumart/${currentSong?.albumId}"

    Box(modifier = Modifier.fillMaxSize()) {
        // Full screen background artwork
        AsyncImage(
            model = artworkUri,
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Dark gradient overlay for readability
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.5f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.8f)
                        )
                    )
                )
        )

        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Now Playing", style = MaterialTheme.typography.titleMedium, color = Color.White) },
                    navigationIcon = {
                        IconButton(onClick = onBackClick) {
                            Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Back", tint = Color.White)
                        }
                    },
                    actions = {
                        IconButton(onClick = { viewModel.toggleLyrics() }) {
                            Icon(
                                imageVector = if (isLyricsEnabled) Icons.Rounded.Lyrics else Icons.Outlined.Lyrics,
                                contentDescription = "Lyrics",
                                tint = if (isLyricsEnabled) Color.Red else Color.White
                            )
                        }
                        IconButton(onClick = { showMenu = true }) {
                            Icon(Icons.Rounded.MoreVert, contentDescription = "More Options", tint = Color.White)
                        }
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false }
                        ) {
                            if (currentSong != null) {
                                DropdownMenuItem(
                                    text = { Text("Share") },
                                    onClick = {
                                        SongActionHandler.handleSongAction(context, SongAction.SHARE, currentSong!!, viewModel)
                                        showMenu = false
                                    },
                                    leadingIcon = { Icon(Icons.Rounded.Share, contentDescription = null) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Set as Ringtone") },
                                    onClick = {
                                        SongActionHandler.handleSongAction(context, SongAction.SET_AS_RINGTONE, currentSong!!, viewModel)
                                        showMenu = false
                                    },
                                    leadingIcon = { Icon(Icons.Rounded.NotificationsActive, contentDescription = null) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Track Info") },
                                    onClick = {
                                        showTechnicalInfo = true
                                        showMenu = false
                                    },
                                    leadingIcon = { Icon(Icons.Rounded.Info, contentDescription = null) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
                                    onClick = {
                                        SongActionHandler.handleSongAction(context, SongAction.DELETE, currentSong!!, viewModel)
                                        showMenu = false
                                        onBackClick() // Go back if deleted
                                    },
                                    leadingIcon = { Icon(Icons.Rounded.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent,
                        titleContentColor = Color.White
                    )
                )
            },
            containerColor = Color.Transparent
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Lyrics or Space
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isLyricsEnabled) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                val lyrics = currentSong?.lyrics
                                if (lyrics.isNullOrBlank()) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            Icons.Rounded.SentimentDissatisfied,
                                            contentDescription = null,
                                            tint = Color.White.copy(alpha = 0.7f),
                                            modifier = Modifier.size(48.dp)
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            "Lyrics not found",
                                            color = Color.White.copy(alpha = 0.7f),
                                            style = MaterialTheme.typography.bodyLarge
                                        )
                                        Spacer(modifier = Modifier.height(16.dp))
                                        Button(
                                            onClick = { currentSong?.let { viewModel.searchLyricsOnline(context, it) } },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = Color.Red,
                                                contentColor = Color.White
                                            ),
                                            shape = CircleShape
                                        ) {
                                            Icon(Icons.Rounded.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Search Online")
                                        }
                                    }
                                } else {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .verticalScroll(rememberScrollState()),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = lyrics,
                                            color = Color.White,
                                            style = MaterialTheme.typography.bodyLarge,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.padding(vertical = 16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Song Info
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(bottom = 24.dp)
                    ) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center
                        )
                        
                        Text(
                            text = artist,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White.copy(alpha = 0.7f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Quality Badges
                        currentSong?.let { song ->
                            FlowRow(
                                horizontalArrangement = Arrangement.Center,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (song.isHiRes) {
                                    QualityBadge("HI-RES", Color.Red.copy(alpha = 0.2f), Color.Red)
                                } else if (song.isLossless) {
                                    QualityBadge("LOSSLESS", Color.White.copy(alpha = 0.15f), Color.White)
                                }

                                if (song.isAtmos) {
                                    QualityBadge("DOLBY ATMOS", Color.White.copy(alpha = 0.15f), Color.White)
                                } else if (song.isDolby) {
                                    QualityBadge("DOLBY", Color.White.copy(alpha = 0.15f), Color.White)
                                }

                                if (song.isDtsX) {
                                    QualityBadge("DTS:X", Color.White.copy(alpha = 0.15f), Color.White)
                                } else if (song.isDts) {
                                    QualityBadge("DTS", Color.White.copy(alpha = 0.15f), Color.White)
                                }

                                val channelText = when (song.channels) {
                                    1 -> "MONO"
                                    2 -> "STEREO"
                                    else -> if (song.channels > 2) "SURROUND" else null
                                }
                                if (channelText != null) {
                                    QualityBadge(channelText, Color.White.copy(alpha = 0.1f), Color.White)
                                }
                            }
                        }

                        if (appSettings.showTechnicalInfo) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                val bitrateText = currentSong?.bitrate?.let { if (it > 0) "${it / 1000} kbps" else "" } ?: ""
                                val sampleRateText = currentSong?.sampleRate?.let { if (it > 0) "${it / 1000.0} kHz" else "" } ?: ""
                                val bitDepthText = currentSong?.bitDepth?.let { if (it > 0) "$it bit" else "" } ?: ""

                                if (bitrateText.isNotEmpty() || sampleRateText.isNotEmpty() || bitDepthText.isNotEmpty()) {
                                    Text(
                                        text = listOf(bitDepthText, sampleRateText, bitrateText).filter { it.isNotEmpty() }.joinToString(" • "),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White.copy(alpha = 0.5f),
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }

                    var sliderPosition by remember(playbackProgress) { mutableFloatStateOf(playbackProgress.toFloat()) }
                    var isSeeking by remember { mutableStateOf(false) }

                    Slider(
                        value = if (isSeeking) sliderPosition else playbackProgress.toFloat(),
                        onValueChange = {
                            isSeeking = true
                            sliderPosition = it
                        },
                        onValueChangeFinished = {
                            viewModel.seekTo(sliderPosition.toLong())
                            isSeeking = false
                        },
                        valueRange = 0f..playbackDuration.toFloat().coerceAtLeast(1f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp),
                        thumb = {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(Color.Red, CircleShape)
                            )
                        },
                        track = { sliderState ->
                            val fraction = if (sliderState.valueRange.endInclusive > sliderState.valueRange.start) {
                                (sliderState.value - sliderState.valueRange.start) / (sliderState.valueRange.endInclusive - sliderState.valueRange.start)
                            } else {
                                0f
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(3.dp),
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                val segmentCount = 35
                                repeat(segmentCount) { index ->
                                    val isFilled = (index + 1).toFloat() / segmentCount <= fraction
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .fillMaxHeight()
                                            .background(
                                                if (isFilled) Color.Red else Color.White.copy(alpha = 0.15f),
                                                shape = CircleShape
                                            )
                                    )
                                }
                            }
                        }
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 28.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = MusicUtils.formatDuration(if (isSeeking) sliderPosition.toLong() else playbackProgress),
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.5f),
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = MusicUtils.formatDuration(playbackDuration),
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.5f),
                            letterSpacing = 0.5.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Controls
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 32.dp),
                        shape = CircleShape,
                        color = Color.White.copy(alpha = 0.1f)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp, horizontal = 16.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { viewModel.toggleShuffleMode() }) {
                                Icon(
                                    Icons.Rounded.Shuffle,
                                    contentDescription = "Shuffle",
                                    tint = if (shuffleModeEnabled) Color.Red else Color.White
                                )
                            }

                            IconButton(
                                onClick = { viewModel.playPrevious() },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(Icons.Rounded.SkipPrevious, contentDescription = "Previous", modifier = Modifier.size(32.dp), tint = Color.White)
                            }

                            Box(contentAlignment = Alignment.Center) {
                                LargeFloatingActionButton(
                                    onClick = { viewModel.togglePlayPause() },
                                    containerColor = Color.Red,
                                    contentColor = Color.White,
                                    shape = CircleShape,
                                    modifier = Modifier.size(72.dp),
                                    elevation = FloatingActionButtonDefaults.elevation(
                                        defaultElevation = 0.dp,
                                        pressedElevation = 0.dp
                                    )
                                ) {
                                    Icon(
                                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                        contentDescription = if (isPlaying) "Pause" else "Play",
                                        modifier = Modifier.size(38.dp)
                                    )
                                }
                            }

                            IconButton(
                                onClick = { viewModel.playNext() },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(Icons.Rounded.SkipNext, contentDescription = "Next", modifier = Modifier.size(32.dp), tint = Color.White)
                            }

                            IconButton(onClick = { viewModel.toggleRepeatMode() }) {
                                val icon = when (repeatMode) {
                                    androidx.media3.common.Player.REPEAT_MODE_ONE -> Icons.Rounded.RepeatOne
                                    else -> Icons.Rounded.Repeat
                                }
                                Icon(
                                    icon,
                                    contentDescription = "Repeat",
                                    tint = if (repeatMode != androidx.media3.common.Player.REPEAT_MODE_OFF) Color.Red else Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showTechnicalInfo && technicalInfo != null && currentSong != null) {
        ModalBottomSheet(
            onDismissRequest = { showTechnicalInfo = false },
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface,
            dragHandle = { BottomSheetDefaults.DragHandle() }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 32.dp)
            ) {
                Text(
                    text = "Track Information",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                InfoItem(label = "Title", value = currentSong!!.title)
                InfoItem(label = "Artist", value = currentSong!!.artist)
                InfoItem(label = "Album", value = currentSong!!.album)
                InfoItem(label = "Year", value = if (currentSong!!.year > 0) currentSong!!.year.toString() else "Unknown")
                
                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outlineVariant)
                
                InfoItem(label = "Format", value = technicalInfo!!.format)
                InfoItem(label = "Bitrate", value = technicalInfo!!.bitrate)
                InfoItem(label = "Sample Rate", value = technicalInfo!!.sampleRate)
                InfoItem(label = "File Size", value = technicalInfo!!.size)
                InfoItem(label = "File Path", value = technicalInfo!!.path)
            }
        }
    }
}

@Composable
fun QualityBadge(
    text: String,
    containerColor: Color = MaterialTheme.colorScheme.surfaceVariant,
    contentColor: Color = MaterialTheme.colorScheme.onSurfaceVariant
) {
    Surface(
        color = containerColor,
        shape = CircleShape,
        modifier = Modifier.padding(2.dp)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 11.sp, 
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            ),
            color = contentColor
        )
    }
}

@Composable
fun InfoItem(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 8.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}
