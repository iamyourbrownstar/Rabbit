package com.brownstar.rabbit.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "albums")
data class Album(
    @PrimaryKey val id: Long,
    val title: String,
    val artist: String,
    val year: Int,
    val trackCount: Int,
    val albumArtUri: String? = null
)
