package com.brownstar.rabbit.util

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import com.brownstar.rabbit.data.model.Song
import com.brownstar.rabbit.ui.viewmodel.MusicViewModel

enum class SongAction {
    DELETE, SHARE, SET_AS_RINGTONE
}

object SongActionHandler {
    fun handleSongAction(context: Context, action: SongAction, song: Song, viewModel: MusicViewModel) {
        when (action) {
            SongAction.DELETE -> {
                viewModel.deleteSong(context, song)
            }
            SongAction.SHARE -> {
                val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, song.id)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "audio/*"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, "Share Track"))
            }
            SongAction.SET_AS_RINGTONE -> {
                if (Settings.System.canWrite(context)) {
                    try {
                        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, song.id)
                        android.media.RingtoneManager.setActualDefaultRingtoneUri(
                            context,
                            android.media.RingtoneManager.TYPE_RINGTONE,
                            uri
                        )
                        Toast.makeText(context, "Ringtone set successfully", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        Toast.makeText(context, "Failed to set ringtone", Toast.LENGTH_SHORT).show()
                        e.printStackTrace()
                    }
                } else {
                    val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                        data = android.net.Uri.parse("package:${context.packageName}")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                }
            }
        }
    }
}
