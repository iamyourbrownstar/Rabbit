# Project Plan

Rabbit: A pro-level music player for local media with Material Design 3 UI, organized library (Albums/Artists), search functionality, separate library and playback screens, a persistent mini-player, and a modern splash screen. YouTube Music integration is to be removed.
Key updates:
1. Remove all YouTube Music networking code, API interactions, and stream extraction logic.
2. Update the search bar to only filter local tracks, albums, and artists.
3. Remove YouTube-specific UI elements (e.g., YouTube search results).
4. Maintain all local playback features, track actions (Delete, Share, Set as Ringtone), and Material 3 design.
5. Ensure the app remains stable and edge-to-edge.

## Project Brief

# Project Brief: Rabbit

Rabbit is a pro-level music player for Android dedicated to high-fidelity local media playback. It features a vibrant, high-energy Material Design 3 interface designed for audiophiles who value organized libraries, seamless navigation, and professional audio controls.

## Features
- **Organized Local Library**: A streamlined browsing experience that categorizes local audio files into Albums and Artists, featuring a high-performance local search bar in the header.
- **Immersive Playback & Navigation**: A dedicated "Now Playing" screen with a customized rounded seek bar and track durations, complemented by a persistent mini-player that ensures constant control while browsing the library.
- **Track Management Suite**: Integrated file actions allowing users to Share, Delete, or Set as Ringtone directly from the library list via long-press or the player's options menu.
- **System-Integrated Audio**: Professional-grade playback powered by AndroidX Media3, providing gapless transitions and direct access to the Android system's default equalizer.
- **Modern Material 3 Entry**: A polished, edge-to-edge user experience that begins with a modern animated splash screen using the Android 12+ API.

## High-Level Technical Stack
- **Language**: Kotlin
- **UI Framework**: Jetpack Compose (Material Design 3)
- **Media Engine**: AndroidX Media3 (ExoPlayer & MediaSession)
- **Navigation**: Jetpack Compose Navigation
- **Startup**: AndroidX SplashScreen API
- **Concurrency**: Kotlin Coroutines & Flow
- **Code Generation**: KSP (Kotlin Symbol Processing)
- **Image Loading**: Coil (optimized for album art rendering)

## Implementation Steps

### Task_1_Data_Media_Foundation: Set up the data layer and core media service foundation. This includes defining Room entities for the music library, implementing a media scanner to discover local audio files, and creating the initial Media3 Service skeleton.
- **Status:** COMPLETED
- **Updates:** I have successfully completed Task 1: Data Media Foundation.
- **Acceptance Criteria:**
  - Room database schema defined for songs, albums, and playlists
  - Local audio file scanner successfully populates the database
  - Media3 Service is declared and initialized in the manifest
  - Project builds successfully

### Task_2_Playback_Engine_Integration: Implement the high-fidelity playback engine using Media3 (ExoPlayer) and MediaSession. Integrate system-level controls for playback notifications and lock-screen support.
- **Status:** COMPLETED
- **Updates:** I have successfully completed Task 2: Playback Engine Integration.
- **Acceptance Criteria:**
  - Audio playback works for various formats (MP3, FLAC, AAC)
  - MediaSession allows control from system notification and lock screen
  - Gapless playback and repeat/shuffle logic implemented
  - Audio focus and noise suppression handled correctly

### Task_3_Library_And_Player_UI: Build the Material Design 3 UI using Jetpack Compose. Create the navigation structure, library browsing screens (Songs, Albums, Artists, Folders), and the Now Playing screen with dynamic coloring based on album art.
- **Status:** COMPLETED
- **Updates:** I have successfully completed Task 3: Library and Player UI.
- **Acceptance Criteria:**
  - Navigation between library sections works smoothly
  - Now Playing screen displays track details and album art via Coil
  - Dynamic M3 color scheme updates based on current track artwork
  - UI follows vibrant, energetic aesthetic with full edge-to-edge display

### Task_4_Advanced_Audio_And_Extras: Implement the pro-level audio features including a multi-band equalizer, bass boost, and preamp. Add secondary features like the tag editor, lyrics display, and create the adaptive app icon.
- **Status:** COMPLETED
- **Updates:** I have successfully completed Task 4: Advanced Audio & Extras, marking the completion of the Rabbit music player.
- **Acceptance Criteria:**
  - Functional parametric equalizer (5-32 bands) with presets
  - Bass boost, treble, and preamp controls are responsive
  - Tag editor and lyrics support implemented
  - Adaptive app icon matches the Rabbit brand and core function

### Task_5_Run_And_Verify: Perform a final comprehensive check of the application to ensure stability, performance, and adherence to requirements. Verify all existing tests pass and the UI meets Material 3 standards.
- **Status:** COMPLETED
- **Updates:** I have successfully completed Task 5: Run and Verify.
- **Acceptance Criteria:**
  - Application is stable with no crashes during library scanning or playback
  - Build passes successfully
  - All core features (EQ, Library, Playback) verified
  - Full compliance with Material Design 3 and edge-to-edge display requirements

### Task_6_Audio_Visualization: Implement real-time audio visualization on the Now Playing screen. Capture audio data using the Visualizer API and render dynamic waveform or frequency spectrum animations using Jetpack Compose Canvas, ensuring high performance and synchronization.
- **Status:** COMPLETED
- **Updates:** I have successfully completed Task 6: Audio Visualization.
- **Acceptance Criteria:**
  - Real-time synchronized visualization on Now Playing screen
  - Visualization colors dynamically adapt to album artwork
  - Performance is maintained without UI stuttering

### Task_7_UI_Navigation_And_MiniPlayer: Refine the navigation architecture to provide smooth transitions between the music library and the dedicated full-screen Now Playing page. Implement an accessible mini-player for persistent playback control across all browsing screens.
- **Status:** COMPLETED
- **Updates:** I have successfully completed Task 7: UI Navigation and MiniPlayer.
- **Acceptance Criteria:**
  - Seamless navigation between Library and Now Playing screens
  - Persistent mini-player allows playback control while browsing
  - Mini-player expands to full-screen Now Playing screen on interaction
  - Full compliance with Material Design 3 and edge-to-edge requirements

### Task_8_SplashScreen_Implementation: Implement the Android 12+ Splash Screen API for a polished animated entry using the Rabbit logo. Ensure smooth transition to the main library screen and compliance with Material Design 3 guidelines.
- **Status:** COMPLETED
- **Updates:** I have successfully completed Task 8: SplashScreen Implementation for the Rabbit music player.
- **Acceptance Criteria:**
  - AndroidX SplashScreen API integrated correctly
  - Splash screen displays and animates the Rabbit logo on app launch
  - Smooth transition to the main UI
  - Complies with Material Design 3 guidelines

### Task_10_UI_Refinements_And_System_EQ: Update the music library to display track durations. Refine the Now Playing screen to show song duration and progress, and customize the seek bar with a modern rounded shape. Remove the custom equalizer and implement a trigger for the system's default equalizer.
- **Status:** COMPLETED
- **Updates:** I have successfully completed Task 10: UI Refinements and System EQ.
- **Acceptance Criteria:**
  - Song durations visible in the library list
  - Now Playing screen displays track progress and total duration
  - Seek bar has a modern, rounded shape
  - App triggers the system default equalizer successfully

### Task_11_YouTube_Integration_Library_Revamp: Integrate YouTube Music for searching and playback. Revamp the Library screen with 'Albums' and 'Artists' sections and a search bar in the header for both local and streaming content. Remove the real-time audio visualization from the Now Playing screen and ensure the mini-player is hidden when the player is active.
- **Status:** COMPLETED
- **Updates:** I have successfully completed Task 11: YouTube Integration & Library Revamp.
- **Acceptance Criteria:**
  - YouTube Music content can be searched and played successfully
  - Library UI includes categorized Albums and Artists sections
  - Search bar in library header functions correctly for local and YT content
  - Audio visualization is removed from the Now Playing screen
  - Mini-player hides when the Now Playing screen is visible
  - Project builds successfully

### Task_12_Track_Management_Actions: Implement track management actions: 'Delete', 'Share', and 'Set as Ringtone'. Enable these actions via a long-press gesture on library list items and through a 'More Options' (overflow) menu on the Now Playing screen. Handle necessary permissions.
- **Status:** COMPLETED
- **Updates:** I have successfully completed Task 12: Track Management Actions for the Rabbit music player.
- **Acceptance Criteria:**
  - Track deletion, sharing, and set-as-ringtone functional
  - Actions accessible via long-press and player overflow menu
  - System permissions for file deletion and write settings handled
  - Material 3 UI patterns followed

### Task_13_Final_Run_And_Verify: Perform a final comprehensive check of the hybrid music player with track management. Verify all features including YouTube Music, library sections, search, and track actions. Instruct critic_agent to verify stability and requirement alignment.
- **Status:** COMPLETED
- **Updates:** I have successfully completed Task 13: Final Run & Verify.
- **Acceptance Criteria:**
  - Application stable with no crashes
  - Hybrid library (local + YouTube Music) works as expected
  - All previous UI refinements and navigation logic (hiding mini-player) remain functional
  - make sure all existing tests pass
  - build pass
  - app does not crash

### Task_14_Remove_YouTube_Integration: Remove all YouTube Music networking code, API interactions, and stream extraction logic. Reconfigure the Library and Search screens to focus exclusively on local media, removing any YouTube-specific UI elements.
- **Status:** COMPLETED
- **Updates:** I have successfully completed Task 14: Remove YouTube Integration.
- **Acceptance Criteria:**
  - Retrofit/OkHttp YouTube interactions and extractors are removed
  - Search bar filters only local tracks, albums, and artists
  - UI is free of YouTube search results or branding
  - Project builds successfully without YouTube-specific dependencies

### Task_15_Final_Verify_Local_Player: Perform a final comprehensive check of the local-only music player. Verify stability of playback, organized library (Albums/Artists), track actions, and Material 3 UI standards. Instruct critic_agent to verify application stability and requirement alignment.
- **Status:** COMPLETED
- **Updates:** I have successfully completed Task 15: Final Verify Local Player.

Key Accomplishments and Verification:
1. Local Library & Search:
    - Confirmed the library is organized into Songs, Albums, and Artists tabs.
    - Verified the search bar only filters local media and is free from any YouTube Music integration.
2. Track Management Actions:
    - Confirmed "Delete", "Share", and "Set as Ringtone" actions are fully functional for local tracks.
    - Actions are accessible via long-press in the library and the overflow menu in the Now Playing screen.
3. UI/UX Refinement:
    - The mini-player correctly hides when the Now Playing screen is visible.
    - Material Design 3 guidelines and Edge-to-Edge display are maintained throughout the application.
    - The splash screen correctly launches and transitions to the library.
4. Stability:
    - The project builds successfully (app:assembleDebug).
    - Local media playback is stable with no crashes.
    - Navigation between the library and player screens is smooth.

The Rabbit music player is now a polished, high-fidelity local-only media player that meets all the specified requirements.
- **Acceptance Criteria:**
  - Application stable with no crashes during local media playback
  - Local library sections (Albums/Artists) and search function correctly
  - All track actions (Delete, Share, Set as Ringtone) are functional
  - Material 3 and edge-to-edge display standards are maintained
  - make sure all existing tests pass
  - build pass
  - app does not crash
- **Duration:** N/A

